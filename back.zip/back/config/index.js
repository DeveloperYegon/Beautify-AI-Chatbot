// config/index.js
module.exports = {
    db: require('./database'),
    vectorstore: require('./vectorstore'),
    langchain: require('./langchain')
  };