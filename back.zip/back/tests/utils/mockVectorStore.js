// tests/utils/mockVectorStore.js
exports.mockVectorStore = {
    similaritySearch: jest.fn().mockResolvedValue([])
  };